%%% load the data 
load('gbest.mat')
load('N.mat')
load('Hcmaes.mat')
HH(:,:,1) = mean(Hcmaes,2);
load('Hde.mat')
HH(:,:,2) = mean(Hde,2);
load('Hga.mat')
HH(:,:,3) = mean(Hga,2);
load('Hms.mat')
HH(:,:,4) = mean(Hms,2);
load('Hpso.mat')
HH(:,:,5) = mean(Hpso,2);
load('Hsa.mat')
HH(:,:,6) = mean(Hsa,2);
%%%
%%% draw the example of cycle ranking paradox in data profile curves of SA, DE, PSO, and CMA-ES
%%%
figure
data_profile(cat(3,HH(:,:,6),HH(:,:,2)),N,1e-1);
legend('SA','DE')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','-.','Color',[1 0 0],'LineWidth',1.5,'Marker','o');
set(h_lines(1,1),'LineStyle','--','Color',[0.15 0.15 0.15],'LineWidth',1.5,'Marker','v');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
data_profile(cat(3,HH(:,:,5),HH(:,:,2)),N,1e-1);
legend('PSO','DE')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','-','Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
set(h_lines(1,1),'LineStyle','--','Color',[0.15 0.15 0.15],'LineWidth',1.5,'Marker','v');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
data_profile(cat(3,HH(:,:,1),HH(:,:,5)),N,1e-1);
legend('CMA-ES','PSO')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
set(h_lines(1,1),'LineStyle','-','Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
data_profile(cat(3,HH(:,:,1),HH(:,:,6)),N,1e-1);
legend('CMA-ES','SA')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
set(h_lines(1,1),'LineStyle','-.','Color',[1 0 0],'LineWidth',1.5,'Marker','o');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
%%%
%%% draw the example of cycle ranking paradox eliminated by the modified data profile curves of SA, DE, PSO, and CMA-ES
%%%
figure
Mdata_profile(cat(3,HH(:,:,6),HH(:,:,2)),N,1e-1,1,gbest);
legend('SA','DE')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','-.','Color',[1 0 0],'LineWidth',1.5,'Marker','o');
set(h_lines(1,1),'LineStyle','--','Color',[0.15 0.15 0.15],'LineWidth',1.5,'Marker','v');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,5),HH(:,:,2)),N,1e-1,1,gbest);
legend('PSO','DE')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','-','Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
set(h_lines(1,1),'LineStyle','--','Color',[0.15 0.15 0.15],'LineWidth',1.5,'Marker','v');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,1),HH(:,:,2)),N,1e-1,1,gbest);
legend('CMA-ES','DE')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
set(h_lines(1,1),'LineStyle','--','Color',[0.15 0.15 0.15],'LineWidth',1.5,'Marker','v');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,1),HH(:,:,5)),N,1e-1,1,gbest);
legend('CMA-ES','PSO')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
set(h_lines(1,1),'LineStyle','-','Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,5),HH(:,:,6)),N,1e-1,1,gbest);
legend('PSO','SA')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','-','Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
set(h_lines(1,1),'LineStyle','-.','Color',[1 0 0],'LineWidth',1.5,'Marker','o');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,1),HH(:,:,6)),N,1e-1,1,gbest);
legend('CMA-ES','SA')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
set(h_lines(1,1),'LineStyle','-.','Color',[1 0 0],'LineWidth',1.5,'Marker','o');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
%%%
%%% draw the example of survival of the non-fittest paradox of data profile curves of GA, PSO, MS, and CMA-ES
%%%
figure
data_profile(cat(3,HH(:,:,3),HH(:,:,5)),N,1e-7);
legend('GA','PSO')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','--','Color',[0.93 0.69 0.13],'LineWidth',1.5,'Marker','*');
set(h_lines(1,1),'Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
data_profile(cat(3,HH(:,:,3),HH(:,:,4)),N,1e-7);
legend('GA','MS')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','--','Color',[0.93 0.69 0.13],'LineWidth',1.5,'Marker','*');
set(h_lines(1,1),'LineStyle','-.','Color',[0.49 0.18 0.56],'LineWidth',1.5,'Marker','^');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
data_profile(cat(3,HH(:,:,5),HH(:,:,4)),N,1e-7);
legend('PSO','MS')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
set(h_lines(1,1),'LineStyle','-.','Color',[0.49 0.18 0.56],'LineWidth',1.5,'Marker','^');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
data_profile(cat(3,HH(:,:,3),HH(:,:,1)),N,1e-7);
legend('GA','CMA-ES')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','--','Color',[0.93 0.69 0.13],'LineWidth',1.5,'Marker','*');
set(h_lines(1,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
data_profile(cat(3,HH(:,:,5),HH(:,:,1)),N,1e-7);
legend('PSO','CMA-ES')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
set(h_lines(1,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
data_profile(cat(3,HH(:,:,4),HH(:,:,1)),N,1e-7);
legend('MS','CMA-ES')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','-.','Color',[0.49 0.18 0.56],'LineWidth',1.5,'Marker','^');
set(h_lines(1,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
data_profile(cat(3,HH(:,:,3),HH(:,:,5),HH(:,:,4),HH(:,:,1)),N,1e-7);
legend('GA','PSO','MS','CMA-ES')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(4,1),'LineStyle','--','Color',[0.93 0.69 0.13],'LineWidth',1.5,'Marker','*');
set(h_lines(3,1),'Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
set(h_lines(2,1),'LineStyle','-.','Color',[0.49 0.18 0.56],'LineWidth',1.5,'Marker','^');
set(h_lines(1,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
%%%
%%% draw the example of survival of the non-fittest paradox eliminated by the modified data profile curves of GA, PSO, MS, and CMA-ES
%%%
figure
Mdata_profile(cat(3,HH(:,:,3),HH(:,:,5)),N,1e-7,1,gbest);
legend('GA','PSO')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','--','Color',[0.93 0.69 0.13],'LineWidth',1.5,'Marker','*');
set(h_lines(1,1),'Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,3),HH(:,:,4)),N,1e-7,1,gbest);
legend('GA','MS')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','--','Color',[0.93 0.69 0.13],'LineWidth',1.5,'Marker','*');
set(h_lines(1,1),'LineStyle','-.','Color',[0.49 0.18 0.56],'LineWidth',1.5,'Marker','^');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,5),HH(:,:,4)),N,1e-7,1,gbest);
legend('PSO','MS')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
set(h_lines(1,1),'LineStyle','-.','Color',[0.49 0.18 0.56],'LineWidth',1.5,'Marker','^');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,3),HH(:,:,1)),N,1e-7,1,gbest);
legend('GA','CMA-ES')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','--','Color',[0.93 0.69 0.13],'LineWidth',1.5,'Marker','*');
set(h_lines(1,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,5),HH(:,:,1)),N,1e-7,1,gbest);
legend('PSO','CMA-ES')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
set(h_lines(1,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,4),HH(:,:,1)),N,1e-7,1,gbest);
legend('MS','CMA-ES')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(2,1),'LineStyle','-.','Color',[0.49 0.18 0.56],'LineWidth',1.5,'Marker','^');
set(h_lines(1,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')
figure
Mdata_profile(cat(3,HH(:,:,3),HH(:,:,5),HH(:,:,4),HH(:,:,1)),N,1e-7,1,gbest);
legend('GA','PSO','MS','CMA-ES')
h_a = gca;
h_lines = get(h_a,'children');
set(h_lines(4,1),'LineStyle','--','Color',[0.93 0.69 0.13],'LineWidth',1.5,'Marker','*');
set(h_lines(3,1),'Color',[0 0.45 0.74],'LineWidth',1.5,'Marker','square');
set(h_lines(2,1),'LineStyle','-.','Color',[0.49 0.18 0.56],'LineWidth',1.5,'Marker','^');
set(h_lines(1,1),'LineStyle',':','Color',[0.47 0.67 0.19],'LineWidth',1.5,'Marker','diamond');
xlabel('Relative computational cost')
ylabel('Percentage of problems solved by algorithm')

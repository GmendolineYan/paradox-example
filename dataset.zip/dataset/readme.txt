gbest                   %%  the matrix storing theoretical global optimum of benchmark functions of the Hedar test set
H_cmaes              %%  the matrix storing the raw data of CMA-ES on the Hedar test set
H_de                    %%  the matrix storing the raw data of DE on the Hedar test set
H_ga                    %%  the matrix storing the raw data of GA on the Hedar test set
H_ms                   %%  the matrix storing the raw data of MS on the Hedar test set
H_pso                  %%  the matrix storing the raw data of PSO on the Hedar test set
H_sa                    %%  the matrix storing the raw data of SA on the Hedar test set
N                         %%  the matrix storing the dimension of benchmark function of the Hedar test set
data_profile        %%  the data profile proposed by J. J. Mor´e and S. M.Wild,
Mdata_profile     %%  the modified data profile proposed by Yuan Yan and Qunfeng Liu
test                      %%  the code to draw the examples of the cycle ranking paradox and the survival of the non-fittest paradox

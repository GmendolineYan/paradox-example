
H = zeros(30,68,6);
for i = 1:68
    H(:,i,1) = Hcmaes(end,:,i);
    H(:,i,2) = Hde(end,:,i);
    H(:,i,3) = Hga(end,:,i);
    H(:,i,4) = Hms(end,:,i);
    H(:,i,5) = Hpso(end,:,i);
    H(:,i,6) = Hsa(end,:,i);
end
MEAN = zeros(68,6);
STD = zeros(68,6);
for i=1:68
    MEAN(i,1) = mean(H(:,i,1));
    MEAN(i,2) = mean(H(:,i,2));
    MEAN(i,3) = mean(H(:,i,3));
    MEAN(i,4) = mean(H(:,i,4));
    MEAN(i,5) = mean(H(:,i,5));
    MEAN(i,6) = mean(H(:,i,6));
end
for i = 1:68
    STD(i,1) = std(H(:,i,1));
    STD(i,2) = std(H(:,i,2));
    STD(i,3) = std(H(:,i,3));
    STD(i,4) = std(H(:,i,4));
    STD(i,5) = std(H(:,i,5));
    STD(i,6) = std(H(:,i,6));
end
h = false(68,15);
p = zeros(68,15);
HH = zeros(68,15);
for k = 1:68
    [p(k,1),h(k,1)] = ranksum(H(:,k,1),H(:,k,2),'Alpha',0.05);
    if h(k,1) == true
        [a,b] = ranksum(H(:,k,1),H(:,k,2),'tail','left','alpha',0.05);
        if b == true
            HH(k,1) = 1;
        else
            [a,b] = ranksum(H(:,k,1),H(:,k,2),'tail','right','alpha',0.05);
            if b == true
                HH(k,1) = 2;
            end
        end
    end
    [p(k,2),h(k,2)] = ranksum(H(:,k,1),H(:,k,3),'Alpha',0.05);
    if h(k,2) == true
        [a,b] = ranksum(H(:,k,1),H(:,k,3),'tail','left','alpha',0.05);
        if b == true
            HH(k,2) = 1;
        else
            [a,b] = ranksum(H(:,k,1),H(:,k,3),'tail','right','alpha',0.05);
            if b == true
                HH(k,2) = 3;
            end
        end
    end
    [p(k,3),h(k,3)] = ranksum(H(:,k,1),H(:,k,4),'Alpha',0.05); 
    if h(k,3) == true
        [a,b] = ranksum(H(:,k,1),H(:,k,4),'tail','left','alpha',0.05);
        if b == true
            HH(k,3) = 1;
        else
            [a,b] = ranksum(H(:,k,1),H(:,k,4),'tail','right','alpha',0.05);
            if b == true
                HH(k,3) = 4;
            end
        end
    end
    [p(k,4),h(k,4)] = ranksum(H(:,k,1),H(:,k,5),'Alpha',0.05);
    if h(k,4) == true
        [a,b] = ranksum(H(:,k,1),H(:,k,5),'tail','left','alpha',0.05);
        if b == true
            HH(k,4) = 1;
        else
            [a,b] = ranksum(H(:,k,1),H(:,k,5),'tail','right','alpha',0.05);
            if b == true
                HH(k,4) = 5;
            end
        end
    end
    [p(k,5),h(k,5)] = ranksum(H(:,k,1),H(:,k,6),'Alpha',0.05);
    if h(k,5) == true
        [a,b] = ranksum(H(:,k,1),H(:,k,6),'tail','left','alpha',0.05);
        if b == true
            HH(k,5) = 1;
        else
            [a,b] = ranksum(H(:,k,1),H(:,k,6),'tail','right','alpha',0.05);
            if b == true
                HH(k,5) = 6;
            end
        end
    end
    [p(k,6),h(k,6)] = ranksum(H(:,k,2),H(:,k,3),'Alpha',0.05);
    if h(k,6) == true
        [a,b] = ranksum(H(:,k,2),H(:,k,3),'tail','left','alpha',0.05);
        if b == true
            HH(k,6) = 2;
        else
            [a,b] = ranksum(H(:,k,2),H(:,k,3),'tail','right','alpha',0.05);
            if b == true
                HH(k,6) = 3;
            end
        end
    end
    [p(k,7),h(k,7)] = ranksum(H(:,k,2),H(:,k,4),'Alpha',0.05);
    if h(k,7) == true
        [a,b] = ranksum(H(:,k,2),H(:,k,4),'tail','left','alpha',0.05);
        if b == true
            HH(k,7) = 2;
        else
            [a,b] = ranksum(H(:,k,2),H(:,k,4),'tail','right','alpha',0.05);
            if b == true
                HH(k,7) = 4;
            end
        end
    end
    [p(k,8),h(k,8)] = ranksum(H(:,k,2),H(:,k,5),'Alpha',0.05);
    if h(k,8) == true
        [a,b] = ranksum(H(:,k,2),H(:,k,5),'tail','left','alpha',0.05);
        if b == true
            HH(k,8) = 2;
        else
            [a,b] = ranksum(H(:,k,2),H(:,k,5),'tail','right','alpha',0.05);
            if b == true
                HH(k,8) = 5;
            end
        end
    end
    [p(k,9),h(k,9)] = ranksum(H(:,k,2),H(:,k,6),'Alpha',0.05);
    if h(k,9) == true
        [a,b] = ranksum(H(:,k,2),H(:,k,6),'tail','left','alpha',0.05);
        if b == true
            HH(k,9) = 2;
        else
            [a,b] = ranksum(H(:,k,2),H(:,k,6),'tail','right','alpha',0.05);
            if b == true
                HH(k,9) = 6;
            end
        end
    end
    [p(k,10),h(k,10)] = ranksum(H(:,k,3),H(:,k,4),'Alpha',0.05);
    if h(k,10) == true
        [a,b] = ranksum(H(:,k,3),H(:,k,4),'tail','left','alpha',0.05);
        if b == true
            HH(k,10) = 3;
        else
            [a,b] = ranksum(H(:,k,3),H(:,k,4),'tail','right','alpha',0.05);
            if b == true
                HH(k,10) = 4;
            end
        end
    end
    [p(k,11),h(k,11)] = ranksum(H(:,k,3),H(:,k,5),'Alpha',0.05);
    if h(k,11) == true
        [a,b] = ranksum(H(:,k,3),H(:,k,5),'tail','left','alpha',0.05);
        if b == true
            HH(k,11) = 3;
        else
            [a,b] = ranksum(H(:,k,3),H(:,k,5),'tail','right','alpha',0.05);
            if b == true
                HH(k,11) = 5;
            end
        end
    end
    [p(k,12),h(k,12)] = ranksum(H(:,k,3),H(:,k,6),'Alpha',0.05);
    if h(k,12) == true
        [a,b] = ranksum(H(:,k,3),H(:,k,6),'tail','left','alpha',0.05);
        if b == true
            HH(k,12) = 3;
        else
            [a,b] = ranksum(H(:,k,3),H(:,k,6),'tail','right','alpha',0.05);
            if b == true
                HH(k,12) = 6;
            end
        end
    end
    [p(k,13),h(k,13)] = ranksum(H(:,k,4),H(:,k,5),'Alpha',0.05);
    if h(k,13) == true
        [a,b] = ranksum(H(:,k,4),H(:,k,5),'tail','left','alpha',0.05);
        if b == true
            HH(k,13) = 4;
        else
            [a,b] = ranksum(H(:,k,4),H(:,k,5),'tail','right','alpha',0.05);
            if b == true
                HH(k,13) = 5;
            end
        end
    end
    [p(k,14),h(k,14)] = ranksum(H(:,k,4),H(:,k,6),'Alpha',0.05);
    if h(k,14) == true
        [a,b] = ranksum(H(:,k,4),H(:,k,6),'tail','left','alpha',0.05);
        if b == true
            HH(k,14) = 4;
        else
            [a,b] = ranksum(H(:,k,4),H(:,k,6),'tail','right','alpha',0.05);
            if b == true
                HH(k,14) = 6;
            end
        end
    end
    [p(k,15),h(k,15)] = ranksum(H(:,k,5),H(:,k,6),'Alpha',0.05);
    if h(k,15) == true
        [a,b] = ranksum(H(:,k,5),H(:,k,6),'tail','left','alpha',0.05);
        if b == true
            HH(k,15) = 5;
        else
            [a,b] = ranksum(H(:,k,5),H(:,k,6),'tail','right','alpha',0.05);
            if b == true
                HH(k,15) = 6;
            end
        end
    end
end

%% 
count (1,1) = sum(HH(:,1) == 1);
count (1,2) = sum(HH(:,1) == 2);
count (1,3) = sum(HH(:,1) == 0);
count (2,1) = sum(HH(:,2) == 1);
count (2,2) = sum(HH(:,2) == 3);
count (2,3) = sum(HH(:,2) == 0);
count (3,1) = sum(HH(:,3) == 1);
count (3,2) = sum(HH(:,3) == 4);
count (3,3) = sum(HH(:,3) == 0);
count (4,1) = sum(HH(:,4) == 1);
count (4,2) = sum(HH(:,4) == 5);
count (4,3) = sum(HH(:,4) == 0);
count (5,1) = sum(HH(:,5) == 1);
count (5,2) = sum(HH(:,5) == 6);
count (5,3) = sum(HH(:,5) == 0);
count (6,1) = sum(HH(:,6) == 2);
count (6,2) = sum(HH(:,6) == 3);
count (6,3) = sum(HH(:,6) == 0);
count (7,1) = sum(HH(:,7) == 2);
count (7,2) = sum(HH(:,7) == 4);
count (7,3) = sum(HH(:,7) == 0);
count (8,1) = sum(HH(:,8) == 2);
count (8,2) = sum(HH(:,8) == 5);
count (8,3) = sum(HH(:,8) == 0);
count (9,1) = sum(HH(:,9) == 2);
count (9,2) = sum(HH(:,9) == 6);
count (9,3) = sum(HH(:,9) == 0);
count (10,1) = sum(HH(:,10) == 3);
count (10,2) = sum(HH(:,10) == 4);
count (10,3) = sum(HH(:,10) == 0);
count (11,1) = sum(HH(:,11) == 3);
count (11,2) = sum(HH(:,11) == 5);
count (11,3) = sum(HH(:,11) == 0);
count (12,1) = sum(HH(:,12) == 3);
count (12,2) = sum(HH(:,12) == 6);
count (12,3) = sum(HH(:,12) == 0);
count (13,1) = sum(HH(:,13) == 4);
count (13,2) = sum(HH(:,13) == 5);
count (13,3) = sum(HH(:,13) == 0);
count (14,1) = sum(HH(:,14) == 4);
count (14,2) = sum(HH(:,14) == 6);
count (14,3) = sum(HH(:,14) == 0);
count (15,1) = sum(HH(:,15) == 5);
count (15,2) = sum(HH(:,15) == 6);
count (15,3) = sum(HH(:,15) == 0);

